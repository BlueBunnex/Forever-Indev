package com.jcraft.jogg;

public class Packet {
	public byte[] packet_base;
	public int packet;
	public int bytes;
	public int b_o_s;
	public int e_o_s;
	public long granulepos;
	public long packetno;
}
