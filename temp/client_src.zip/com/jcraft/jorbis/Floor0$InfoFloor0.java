package com.jcraft.jorbis;

class Floor0$InfoFloor0 {
	int order;
	int rate;
	int barkmap;
	int ampbits;
	int ampdB;
	int numbooks;
	int[] books;
	final Floor0 this$0;

	Floor0$InfoFloor0(Floor0 floor01) {
		this.this$0 = floor01;
		this.books = new int[16];
	}
}
