package com.jcraft.jorbis;

class Lsp {
	static final float M_PI = 3.1415927F;

	static void lsp_to_curve(float[] f0, int[] i1, int i2, int i3, float[] f4, int i5, float f6, float f7) {
		float f8 = 3.1415927F / (float)i3;

		for(i3 = 0; i3 < i5; ++i3) {
			f4[i3] = Lookup.coslook(f4[i3]);
		}

		int i9 = i5 / 2 << 1;
		i3 = 0;

		while(i3 < i2) {
			int i10 = i1[i3];
			float f11 = 0.70710677F;
			float f12 = 0.70710677F;
			float f13 = Lookup.coslook(f8 * (float)i10);

			int i14;
			for(i14 = 0; i14 < i9; i14 += 2) {
				f12 *= f4[i14] - f13;
				f11 *= f4[i14 + 1] - f13;
			}

			if((i5 & 1) != 0) {
				f12 = (f12 *= f4[i5 - 1] - f13) * f12;
				f11 *= f11 * (1.0F - f13 * f13);
			} else {
				f12 *= f12 * (f13 + 1.0F);
				f11 *= f11 * (1.0F - f13);
			}

			i14 = Float.floatToIntBits(f12 += f11);
			int i15 = Integer.MAX_VALUE & i14;
			int i16 = 0;
			if(i15 < 2139095040 && i15 != 0) {
				if(i15 < 8388608) {
					i14 = Float.floatToIntBits((float)((double)f12 * 3.3554432E7D));
					i15 = Integer.MAX_VALUE & i14;
					i16 = -25;
				}

				i16 += (i15 >>> 23) - 126;
				f12 = Float.intBitsToFloat(i14 & -2139095041 | 1056964608);
			}

			f12 = Lookup.fromdBlook(f6 * Lookup.invsqlook(f12) * Lookup.invsq2explook(i16 + i5) - f7);

			while(true) {
				int i10001 = i3++;
				f0[i10001] *= f12;
				if(i3 >= i2 || i1[i3] != i10) {
					break;
				}
			}
		}

	}
}
