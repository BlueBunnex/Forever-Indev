package com.jcraft.jorbis;

class Residue2 extends Residue0 {
	int inverse(Block block1, Object object2, float[][] f3, int[] i4, int i5) {
		int i6;
		for(i6 = 0; i6 < i5 && i4[i6] == 0; ++i6) {
		}

		return i6 == i5 ? 0 : _2inverse(block1, object2, f3, i5);
	}
}
