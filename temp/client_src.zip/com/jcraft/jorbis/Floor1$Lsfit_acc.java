package com.jcraft.jorbis;

class Floor1$Lsfit_acc {
	long x0;
	long x1;
	long xa;
	long ya;
	long x2a;
	long y2a;
	long xya;
	long n;
	long an;
	long un;
	long edgey0;
	long edgey1;
	final Floor1 this$0;

	Floor1$Lsfit_acc(Floor1 floor11) {
		this.this$0 = floor11;
	}
}
