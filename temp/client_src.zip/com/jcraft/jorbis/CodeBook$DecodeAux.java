package com.jcraft.jorbis;

class CodeBook$DecodeAux {
	int[] tab;
	int[] tabl;
	int tabn;
	int[] ptr0;
	int[] ptr1;
	int aux;
	final CodeBook this$0;

	CodeBook$DecodeAux(CodeBook codeBook1) {
		this.this$0 = codeBook1;
	}
}
