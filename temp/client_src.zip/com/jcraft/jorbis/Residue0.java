package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class Residue0 extends FuncResidue {
	private static int[][][] _01inverse_partword = new int[2][][];
	static int[][] _2inverse_partword = null;

	void pack(Object object1, Buffer buffer2) {
		Residue0$InfoResidue0 residue0$InfoResidue06 = (Residue0$InfoResidue0)object1;
		int i3 = 0;
		buffer2.write(residue0$InfoResidue06.begin, 24);
		buffer2.write(residue0$InfoResidue06.end, 24);
		buffer2.write(residue0$InfoResidue06.grouping - 1, 24);
		buffer2.write(residue0$InfoResidue06.partitions - 1, 6);
		buffer2.write(residue0$InfoResidue06.groupbook, 8);

		int i4;
		for(i4 = 0; i4 < residue0$InfoResidue06.partitions; ++i4) {
			int i5;
			if(Util.ilog(i5 = residue0$InfoResidue06.secondstages[i4]) > 3) {
				buffer2.write(i5, 3);
				buffer2.write(1, 1);
				buffer2.write(i5 >>> 3, 5);
			} else {
				buffer2.write(i5, 4);
			}

			i3 += Util.icount(i5);
		}

		for(i4 = 0; i4 < i3; ++i4) {
			buffer2.write(residue0$InfoResidue06.booklist[i4], 8);
		}

	}

	Object unpack(Info info1, Buffer buffer2) {
		int i3 = 0;
		Residue0$InfoResidue0 residue0$InfoResidue04;
		(residue0$InfoResidue04 = new Residue0$InfoResidue0(this)).begin = buffer2.read(24);
		residue0$InfoResidue04.end = buffer2.read(24);
		residue0$InfoResidue04.grouping = buffer2.read(24) + 1;
		residue0$InfoResidue04.partitions = buffer2.read(6) + 1;
		residue0$InfoResidue04.groupbook = buffer2.read(8);

		int i5;
		for(i5 = 0; i5 < residue0$InfoResidue04.partitions; ++i5) {
			int i6 = buffer2.read(3);
			if(buffer2.read(1) != 0) {
				i6 |= buffer2.read(5) << 3;
			}

			residue0$InfoResidue04.secondstages[i5] = i6;
			i3 += Util.icount(i6);
		}

		for(i5 = 0; i5 < i3; ++i5) {
			residue0$InfoResidue04.booklist[i5] = buffer2.read(8);
		}

		if(residue0$InfoResidue04.groupbook >= info1.books) {
			this.free_info(residue0$InfoResidue04);
			return null;
		} else {
			for(i5 = 0; i5 < i3; ++i5) {
				if(residue0$InfoResidue04.booklist[i5] >= info1.books) {
					this.free_info(residue0$InfoResidue04);
					return null;
				}
			}

			return residue0$InfoResidue04;
		}
	}

	Object look(DspState dspState1, InfoMode infoMode2, Object object3) {
		Residue0$InfoResidue0 residue0$InfoResidue012 = (Residue0$InfoResidue0)object3;
		Residue0$LookResidue0 residue0$LookResidue04 = new Residue0$LookResidue0(this);
		int i5 = 0;
		int i6 = 0;
		residue0$LookResidue04.info = residue0$InfoResidue012;
		residue0$LookResidue04.map = infoMode2.mapping;
		residue0$LookResidue04.parts = residue0$InfoResidue012.partitions;
		residue0$LookResidue04.fullbooks = dspState1.fullbooks;
		residue0$LookResidue04.phrasebook = dspState1.fullbooks[residue0$InfoResidue012.groupbook];
		int i10 = residue0$LookResidue04.phrasebook.dim;
		residue0$LookResidue04.partbooks = new int[residue0$LookResidue04.parts][];

		int i7;
		int i8;
		int i9;
		int i11;
		for(i11 = 0; i11 < residue0$LookResidue04.parts; ++i11) {
			if((i8 = Util.ilog(i7 = residue0$InfoResidue012.secondstages[i11])) != 0) {
				if(i8 > i6) {
					i6 = i8;
				}

				residue0$LookResidue04.partbooks[i11] = new int[i8];

				for(i9 = 0; i9 < i8; ++i9) {
					if((i7 & 1 << i9) != 0) {
						residue0$LookResidue04.partbooks[i11][i9] = residue0$InfoResidue012.booklist[i5++];
					}
				}
			}
		}

		residue0$LookResidue04.partvals = (int)Math.rint(Math.pow((double)residue0$LookResidue04.parts, (double)i10));
		residue0$LookResidue04.stages = i6;
		residue0$LookResidue04.decodemap = new int[residue0$LookResidue04.partvals][];

		for(i11 = 0; i11 < residue0$LookResidue04.partvals; ++i11) {
			i7 = i11;
			i8 = residue0$LookResidue04.partvals / residue0$LookResidue04.parts;
			residue0$LookResidue04.decodemap[i11] = new int[i10];

			for(i9 = 0; i9 < i10; ++i9) {
				int i13 = i7 / i8;
				i7 -= i13 * i8;
				i8 /= residue0$LookResidue04.parts;
				residue0$LookResidue04.decodemap[i11][i9] = i13;
			}
		}

		return residue0$LookResidue04;
	}

	void free_info(Object object1) {
	}

	void free_look(Object object1) {
	}

	static synchronized int _01inverse(Block block0, Object object1, float[][] f2, int i3, int i4) {
		Residue0$LookResidue0 residue0$LookResidue09;
		Residue0$InfoResidue0 residue0$InfoResidue010;
		int i11 = (residue0$InfoResidue010 = (residue0$LookResidue09 = (Residue0$LookResidue0)object1).info).grouping;
		int i12 = residue0$LookResidue09.phrasebook.dim;
		int i13;
		int i16 = ((i13 = (residue0$InfoResidue010.end - residue0$InfoResidue010.begin) / i11) + i12 - 1) / i12;
		if(_01inverse_partword.length < i3) {
			_01inverse_partword = new int[i3][][];
		}

		int i5;
		for(i5 = 0; i5 < i3; ++i5) {
			if(_01inverse_partword[i5] == null || _01inverse_partword[i5].length < i16) {
				_01inverse_partword[i5] = new int[i16][];
			}
		}

		for(int i8 = 0; i8 < residue0$LookResidue09.stages; ++i8) {
			i16 = 0;

			for(int i7 = 0; i16 < i13; ++i7) {
				int i14;
				if(i8 == 0) {
					for(i5 = 0; i5 < i3; ++i5) {
						if((i14 = residue0$LookResidue09.phrasebook.decode(block0.opb)) == -1) {
							return 0;
						}

						_01inverse_partword[i5][i7] = residue0$LookResidue09.decodemap[i14];
						if(_01inverse_partword[i5][i7] == null) {
							return 0;
						}
					}
				}

				for(int i6 = 0; i6 < i12 && i16 < i13; ++i16) {
					for(i5 = 0; i5 < i3; ++i5) {
						i14 = residue0$InfoResidue010.begin + i16 * i11;
						int i15 = _01inverse_partword[i5][i7][i6];
						CodeBook codeBook17;
						if((residue0$InfoResidue010.secondstages[i15] & 1 << i8) != 0 && (codeBook17 = residue0$LookResidue09.fullbooks[residue0$LookResidue09.partbooks[i15][i8]]) != null) {
							if(i4 == 0) {
								if(codeBook17.decodevs_add(f2[i5], i14, block0.opb, i11) == -1) {
									return 0;
								}
							} else if(i4 == 1 && codeBook17.decodev_add(f2[i5], i14, block0.opb, i11) == -1) {
								return 0;
							}
						}
					}

					++i6;
				}
			}
		}

		return 0;
	}

	static synchronized int _2inverse(Block block0, Object object1, float[][] f2, int i3) {
		Residue0$LookResidue0 residue0$LookResidue07;
		Residue0$InfoResidue0 residue0$InfoResidue08;
		int i9 = (residue0$InfoResidue08 = (residue0$LookResidue07 = (Residue0$LookResidue0)object1).info).grouping;
		int i10 = residue0$LookResidue07.phrasebook.dim;
		int i11;
		int i14 = ((i11 = (residue0$InfoResidue08.end - residue0$InfoResidue08.begin) / i9) + i10 - 1) / i10;
		if(_2inverse_partword == null || _2inverse_partword.length < i14) {
			_2inverse_partword = new int[i14][];
		}

		for(int i6 = 0; i6 < residue0$LookResidue07.stages; ++i6) {
			i14 = 0;

			for(int i5 = 0; i14 < i11; ++i5) {
				int i12;
				if(i6 == 0) {
					if((i12 = residue0$LookResidue07.phrasebook.decode(block0.opb)) == -1) {
						return 0;
					}

					_2inverse_partword[i5] = residue0$LookResidue07.decodemap[i12];
					if(_2inverse_partword[i5] == null) {
						return 0;
					}
				}

				for(int i4 = 0; i4 < i10 && i14 < i11; ++i14) {
					i12 = residue0$InfoResidue08.begin + i14 * i9;
					int i13 = _2inverse_partword[i5][i4];
					CodeBook codeBook15;
					if((residue0$InfoResidue08.secondstages[i13] & 1 << i6) != 0 && (codeBook15 = residue0$LookResidue07.fullbooks[residue0$LookResidue07.partbooks[i13][i6]]) != null && codeBook15.decodevv_add(f2, i12, i3, block0.opb, i9) == -1) {
						return 0;
					}

					++i4;
				}
			}
		}

		return 0;
	}

	int inverse(Block block1, Object object2, float[][] f3, int[] i4, int i5) {
		int i6 = 0;

		for(int i7 = 0; i7 < i5; ++i7) {
			if(i4[i7] != 0) {
				f3[i6++] = f3[i7];
			}
		}

		if(i6 != 0) {
			return _01inverse(block1, object2, f3, i6, 0);
		} else {
			return 0;
		}
	}
}
