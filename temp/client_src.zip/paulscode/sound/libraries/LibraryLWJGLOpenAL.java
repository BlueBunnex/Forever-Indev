package paulscode.sound.libraries;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Iterator;
import javax.sound.sampled.AudioFormat;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;

import paulscode.sound.Channel;
import paulscode.sound.FilenameURL;
import paulscode.sound.ICodec;
import paulscode.sound.Library;
import paulscode.sound.ListenerData;
import paulscode.sound.SoundBuffer;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemException;
import paulscode.sound.Source;

public class LibraryLWJGLOpenAL extends Library {
	private static final boolean GET = false;
	private static final boolean SET = true;
	private static final boolean XXX = false;
	private FloatBuffer listenerPositionAL = null;
	private FloatBuffer listenerOrientation = null;
	private FloatBuffer listenerVelocity = null;
	private HashMap ALBufferMap = null;
	private static boolean alPitchSupported = true;

	public LibraryLWJGLOpenAL() {
		this.ALBufferMap = new HashMap();
	}

	public void init() {
		boolean z1;
		try {
			AL.create();
			z1 = this.checkALError();
		} catch (LWJGLException lWJGLException3) {
			this.errorMessage("Unable to initialize OpenAL.  Probable cause: OpenAL not supported.");
			this.printStackTrace(lWJGLException3);
			throw new SoundSystemException(lWJGLException3.getMessage(), 6);
		}

		if(z1) {
			this.importantMessage("OpenAL did not initialize properly!");
		} else {
			this.message("OpenAL initialized.");
		}

		this.listenerPositionAL = BufferUtils.createFloatBuffer(3).put(new float[]{this.listener.position.x, this.listener.position.y, this.listener.position.z});
		this.listenerOrientation = BufferUtils.createFloatBuffer(6).put(new float[]{this.listener.lookAt.x, this.listener.lookAt.y, this.listener.lookAt.z, this.listener.up.x, this.listener.up.y, this.listener.up.z});
		this.listenerVelocity = BufferUtils.createFloatBuffer(3).put(new float[]{0.0F, 0.0F, 0.0F});
		this.listenerPositionAL.flip();
		this.listenerOrientation.flip();
		this.listenerVelocity.flip();
		AL10.alListener(4100, this.listenerPositionAL);
		z1 = this.checkALError() || z1;
		AL10.alListener(4111, this.listenerOrientation);
		z1 = this.checkALError() || z1;
		AL10.alListener(4102, this.listenerVelocity);
		if(this.checkALError() || z1) {
			this.importantMessage("OpenAL did not initialize properly!");
			throw new SoundSystemException("Problem encountered while loading OpenAL or creating the listener.  Probably cause:  OpenAL not supported", 6);
		} else {
			super.init();
			ChannelLWJGLOpenAL channelLWJGLOpenAL4 = (ChannelLWJGLOpenAL)this.normalChannels.get(1);

			try {
				AL10.alSourcef(channelLWJGLOpenAL4.ALSource.get(0), 4099, 1.0F);
				if(this.checkALError()) {
					alPitchSupported(true, false);
					throw new SoundSystemException("OpenAL: AL_PITCH not supported.", 13);
				} else {
					alPitchSupported(true, true);
				}
			} catch (Exception exception2) {
				alPitchSupported(true, false);
				throw new SoundSystemException("OpenAL: AL_PITCH not supported.", 13);
			}
		}
	}

	public static boolean libraryCompatible() {
		if(AL.isCreated()) {
			return true;
		} else {
			try {
				AL.create();
			} catch (Exception exception1) {
				return false;
			}

			try {
				AL.destroy();
			} catch (Exception exception0) {
			}

			return true;
		}
	}

	protected Channel createChannel(int i1) {
		IntBuffer intBuffer2 = BufferUtils.createIntBuffer(1);

		try {
			AL10.alGenSources(intBuffer2);
		} catch (Exception exception3) {
			AL10.alGetError();
			return null;
		}

		return AL10.alGetError() != 0 ? null : new ChannelLWJGLOpenAL(i1, intBuffer2);
	}

	public void cleanup() {
		super.cleanup();
		Iterator iterator1 = this.bufferMap.keySet().iterator();

		while(iterator1.hasNext()) {
			String string2 = (String)iterator1.next();
			IntBuffer intBuffer3;
			if((intBuffer3 = (IntBuffer)this.ALBufferMap.get(string2)) != null) {
				AL10.alDeleteBuffers(intBuffer3);
				this.checkALError();
				intBuffer3.clear();
			}
		}

		this.bufferMap.clear();
		AL.destroy();
		this.bufferMap = null;
		this.listenerPositionAL = null;
		this.listenerOrientation = null;
		this.listenerVelocity = null;
	}

	public boolean loadSound(FilenameURL filenameURL1) {
		if(this.bufferMap == null) {
			this.bufferMap = new HashMap();
			this.importantMessage("Buffer Map was null in method \'loadSound\'");
		}

		if(this.ALBufferMap == null) {
			this.ALBufferMap = new HashMap();
			this.importantMessage("Open AL Buffer Map was null in method\'loadSound\'");
		}

		if(this.errorCheck(filenameURL1 == null, "Filename/URL not specified in method \'loadSound\'")) {
			return false;
		} else if(this.bufferMap.get(filenameURL1.getFilename()) != null) {
			return true;
		} else {
			ICodec iCodec2 = SoundSystemConfig.getCodec(filenameURL1.getFilename());
			if(this.errorCheck(iCodec2 == null, "No codec found for file \'" + filenameURL1.getFilename() + "\' in method \'loadSound\'")) {
				return false;
			} else {
				iCodec2.initialize(filenameURL1.getURL());
				SoundBuffer soundBuffer3 = iCodec2.readAll();
				iCodec2.cleanup();
				if(this.errorCheck(soundBuffer3 == null, "Sound buffer null in method \'loadSound\'")) {
					return false;
				} else {
					this.bufferMap.put(filenameURL1.getFilename(), soundBuffer3);
					AudioFormat audioFormat7 = soundBuffer3.audioFormat;
					short s4;
					if(soundBuffer3.audioFormat.getChannels() == 1) {
						if(audioFormat7.getSampleSizeInBits() == 8) {
							s4 = 4352;
						} else {
							if(audioFormat7.getSampleSizeInBits() != 16) {
								this.errorMessage("Illegal sample size in method \'loadSound\'");
								return false;
							}

							s4 = 4353;
						}
					} else {
						if(audioFormat7.getChannels() != 2) {
							this.errorMessage("File neither mono nor stereo in method \'loadSound\'");
							return false;
						}

						if(audioFormat7.getSampleSizeInBits() == 8) {
							s4 = 4354;
						} else {
							if(audioFormat7.getSampleSizeInBits() != 16) {
								this.errorMessage("Illegal sample size in method \'loadSound\'");
								return false;
							}

							s4 = 4355;
						}
					}

					IntBuffer intBuffer5;
					AL10.alGenBuffers(intBuffer5 = BufferUtils.createIntBuffer(1));
					if(this.errorCheck(AL10.alGetError() != 0, "alGenBuffers error when loading " + filenameURL1.getFilename())) {
						return false;
					} else {
						ByteBuffer byteBuffer6;
						(byteBuffer6 = BufferUtils.createByteBuffer(soundBuffer3.audioData.length)).clear();
						byteBuffer6.put(soundBuffer3.audioData);
						byteBuffer6.flip();
						AL10.alBufferData(intBuffer5.get(0), s4, byteBuffer6, (int)audioFormat7.getSampleRate());
						if(this.errorCheck(AL10.alGetError() != 0, "alBufferData error when loading " + filenameURL1.getFilename()) && this.errorCheck(intBuffer5 == null, "Sound buffer was not created for " + filenameURL1.getFilename())) {
							return false;
						} else {
							this.ALBufferMap.put(filenameURL1.getFilename(), intBuffer5);
							return true;
						}
					}
				}
			}
		}
	}

	public void unloadSound(String string1) {
		this.ALBufferMap.remove(string1);
		super.unloadSound(string1);
	}

	public void setMasterVolume(float f1) {
		super.setMasterVolume(f1);
		AL10.alListenerf(4106, f1);
		this.checkALError();
	}

	public void newSource(boolean z1, boolean z2, boolean z3, String string4, FilenameURL filenameURL5, float f6, float f7, float f8, int i9, float f10) {
		IntBuffer intBuffer11 = null;
		if(!z2) {
			if((IntBuffer)this.ALBufferMap.get(filenameURL5.getFilename()) == null && !this.loadSound(filenameURL5)) {
				this.errorMessage("Source \'" + string4 + "\' was not created " + "because an error occurred while loading " + filenameURL5.getFilename());
				return;
			}

			if((intBuffer11 = (IntBuffer)this.ALBufferMap.get(filenameURL5.getFilename())) == null) {
				this.errorMessage("Source \'" + string4 + "\' was not created " + "because a sound buffer was not found for " + filenameURL5.getFilename());
				return;
			}
		}

		SoundBuffer soundBuffer12 = null;
		if(!z2) {
			if((SoundBuffer)this.bufferMap.get(filenameURL5.getFilename()) == null && !this.loadSound(filenameURL5)) {
				this.errorMessage("Source \'" + string4 + "\' was not created " + "because an error occurred while loading " + filenameURL5.getFilename());
				return;
			}

			if((soundBuffer12 = (SoundBuffer)this.bufferMap.get(filenameURL5.getFilename())) == null) {
				this.errorMessage("Source \'" + string4 + "\' was not created " + "because audio data was not found for " + filenameURL5.getFilename());
				return;
			}
		}

		this.sourceMap.put(string4, new SourceLWJGLOpenAL(this.listenerPositionAL, intBuffer11, z1, z2, z3, string4, filenameURL5, soundBuffer12, f6, f7, f8, i9, f10, false));
	}

	public void rawDataStream(AudioFormat audioFormat1, boolean z2, String string3, float f4, float f5, float f6, int i7, float f8) {
		this.sourceMap.put(string3, new SourceLWJGLOpenAL(this.listenerPositionAL, audioFormat1, z2, string3, f4, f5, f6, i7, f8));
	}

	public void quickPlay(boolean z1, boolean z2, boolean z3, String string4, FilenameURL filenameURL5, float f6, float f7, float f8, int i9, float f10, boolean z11) {
		IntBuffer intBuffer12 = null;
		if(!z2) {
			if((IntBuffer)this.ALBufferMap.get(filenameURL5.getFilename()) == null) {
				this.loadSound(filenameURL5);
			}

			if((intBuffer12 = (IntBuffer)this.ALBufferMap.get(filenameURL5.getFilename())) == null) {
				this.errorMessage("Sound buffer was not created for " + filenameURL5.getFilename());
				return;
			}
		}

		SoundBuffer soundBuffer13 = null;
		if(!z2) {
			if((SoundBuffer)this.bufferMap.get(filenameURL5.getFilename()) == null && !this.loadSound(filenameURL5)) {
				this.errorMessage("Source \'" + string4 + "\' was not created " + "because an error occurred while loading " + filenameURL5.getFilename());
				return;
			}

			if((soundBuffer13 = (SoundBuffer)this.bufferMap.get(filenameURL5.getFilename())) == null) {
				this.errorMessage("Source \'" + string4 + "\' was not created " + "because audio data was not found for " + filenameURL5.getFilename());
				return;
			}
		}

		SourceLWJGLOpenAL sourceLWJGLOpenAL14 = new SourceLWJGLOpenAL(this.listenerPositionAL, intBuffer12, z1, z2, z3, string4, filenameURL5, soundBuffer13, f6, f7, f8, i9, f10, false);
		this.sourceMap.put(string4, sourceLWJGLOpenAL14);
		this.play(sourceLWJGLOpenAL14);
		if(z11) {
			sourceLWJGLOpenAL14.setTemporary(true);
		}

	}

	public void copySources(HashMap hashMap1) {
		if(hashMap1 != null) {
			Iterator iterator2 = hashMap1.keySet().iterator();
			if(this.bufferMap == null) {
				this.bufferMap = new HashMap();
				this.importantMessage("Buffer Map was null in method \'copySources\'");
			}

			if(this.ALBufferMap == null) {
				this.ALBufferMap = new HashMap();
				this.importantMessage("Open AL Buffer Map was null in method\'copySources\'");
			}

			this.sourceMap.clear();

			while(true) {
				String string3;
				Source source4;
				SoundBuffer soundBuffer5;
				do {
					do {
						if(!iterator2.hasNext()) {
							return;
						}

						string3 = (String)iterator2.next();
					} while((source4 = (Source)hashMap1.get(string3)) == null);

					soundBuffer5 = null;
					if(!source4.toStream) {
						this.loadSound(source4.filenameURL);
						soundBuffer5 = (SoundBuffer)this.bufferMap.get(source4.filenameURL.getFilename());
					}
				} while(!source4.toStream && soundBuffer5 == null);

				this.sourceMap.put(string3, new SourceLWJGLOpenAL(this.listenerPositionAL, (IntBuffer)this.ALBufferMap.get(source4.filenameURL.getFilename()), source4, soundBuffer5));
			}
		}
	}

	public void setListenerPosition(float f1, float f2, float f3) {
		super.setListenerPosition(f1, f2, f3);
		this.listenerPositionAL.put(0, f1);
		this.listenerPositionAL.put(1, f2);
		this.listenerPositionAL.put(2, f3);
		AL10.alListener(4100, this.listenerPositionAL);
		this.checkALError();
	}

	public void setListenerAngle(float f1) {
		super.setListenerAngle(f1);
		this.listenerOrientation.put(0, this.listener.lookAt.x);
		this.listenerOrientation.put(2, this.listener.lookAt.z);
		AL10.alListener(4111, this.listenerOrientation);
		this.checkALError();
	}

	public void setListenerOrientation(float f1, float f2, float f3, float f4, float f5, float f6) {
		super.setListenerOrientation(f1, f2, f3, f4, f5, f6);
		this.listenerOrientation.put(0, f1);
		this.listenerOrientation.put(1, f2);
		this.listenerOrientation.put(2, f3);
		this.listenerOrientation.put(3, f4);
		this.listenerOrientation.put(4, f5);
		this.listenerOrientation.put(5, f6);
		AL10.alListener(4111, this.listenerOrientation);
		this.checkALError();
	}

	public void setListenerData(ListenerData listenerData1) {
		super.setListenerData(listenerData1);
		this.listenerPositionAL.put(0, listenerData1.position.x);
		this.listenerPositionAL.put(1, listenerData1.position.y);
		this.listenerPositionAL.put(2, listenerData1.position.z);
		AL10.alListener(4100, this.listenerPositionAL);
		this.listenerOrientation.put(0, listenerData1.lookAt.x);
		this.listenerOrientation.put(1, listenerData1.lookAt.y);
		this.listenerOrientation.put(2, listenerData1.lookAt.z);
		this.listenerOrientation.put(3, listenerData1.up.x);
		this.listenerOrientation.put(4, listenerData1.up.y);
		this.listenerOrientation.put(5, listenerData1.up.z);
		AL10.alListener(4111, this.listenerOrientation);
		this.checkALError();
	}

	private boolean checkALError() {
		switch(AL10.alGetError()) {
		case 0:
			return false;
		case 40961:
			this.errorMessage("Invalid name parameter.");
			return true;
		case 40962:
			this.errorMessage("Invalid parameter.");
			return true;
		case 40963:
			this.errorMessage("Invalid enumerated parameter value.");
			return true;
		case 40964:
			this.errorMessage("Illegal call.");
			return true;
		case 40965:
			this.errorMessage("Unable to allocate memory.");
			return true;
		default:
			this.errorMessage("An unrecognized error occurred.");
			return true;
		}
	}

	public static boolean alPitchSupported() {
		return alPitchSupported(false, false);
	}

	private static synchronized boolean alPitchSupported(boolean z0, boolean z1) {
		if(z0) {
			alPitchSupported = z1;
		}

		return alPitchSupported;
	}

	public static String getTitle() {
		return "LWJGL OpenAL";
	}

	public static String getDescription() {
		return "The LWJGL binding of OpenAL.  For more information, see http://www.lwjgl.org";
	}

	public String getClassName() {
		return "LibraryLWJGLOpenAL";
	}
}
