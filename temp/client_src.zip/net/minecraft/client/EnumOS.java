package net.minecraft.client;

enum EnumOS {
	linux,
	solaris,
	windows,
	macos,
	unknown;
}
