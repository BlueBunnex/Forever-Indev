package net.minecraft.client.player;

public class MovementInput {
	public float moveStrafe = 0.0F;
	public float moveForward = 0.0F;
	public boolean jump = false;

	public void updatePlayerMoveState() {
	}

	public void resetKeyState() {
	}

	public void checkKeyForMovementInput(int i1, boolean z2) {
	}
}
