package net.minecraft.game.level.material;

public final class MaterialTransparent extends Material {
	public final boolean isSolid() {
		return false;
	}

	public final boolean getCanBlockGrass() {
		return false;
	}

	public final boolean getIsSolid() {
		return false;
	}
}
